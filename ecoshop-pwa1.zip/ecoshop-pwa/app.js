if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js')
        .then(reg => console.log('Service Worker registrado com sucesso:', reg))
        .catch(err => console.error('Falha ao registrar o Service Worker:', err));
}

document.getElementById('notify-btn').addEventListener('click', () => {
    alert('Você será notificado em breve!');
});
